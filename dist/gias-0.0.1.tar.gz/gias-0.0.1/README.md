# Get Information About Schools API

This is a Python 3 wrapper for the Department for Education's Get Information About Schools API.
