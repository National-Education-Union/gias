# Get Information About Schools

A Python 3 wrapper for the Department for Education's Get Information About Schools API.

## Install
```
pip install git+https://github.com/National-Education-Union/gias
```

## Examples

### Set up
```python

from gias import GetInformationAboutSchools
gias = GetInformationAboutSchools(
